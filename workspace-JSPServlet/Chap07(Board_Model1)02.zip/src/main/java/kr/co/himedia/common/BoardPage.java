package kr.co.himedia.common;

public class BoardPage {

	public static String pagingStr(int totalCount, int pageSize, int blockPage, int pageNum, String reqUrl) {
		String pagingStr = "";
		
		// 3 단계 : 전체 페이지 수 계산 
		int totalPages = (int)(Math.ceil((double)totalCount / pageSize));
		
		// 4 단계 : '이전 페이지 블록 바로가기'
		int pageTemp = ((pageNum-1)/blockPage)*blockPage + 1;
		if (pageTemp != 1) {								// pageTemp가 1 아닐 때만 [첫 페이지]와 [이전 블록] 링크를 출력함 
			pagingStr += "<a href='"+reqUrl+"?pageNum=1'>[첫 페이지]</a>";
			pagingStr += "&nbsp;";
			pagingStr += "<a href='"+reqUrl+"?pageNum="+(pageTemp-1)+"'>[이전 블록]</a>";
		}
				
		
		
		
		
		return pagingStr;
	}
}
