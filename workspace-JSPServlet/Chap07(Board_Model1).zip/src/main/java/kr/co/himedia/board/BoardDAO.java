package kr.co.himedia.board;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletContext;

public class BoardDAO extends JDBConnection {

	public BoardDAO(ServletContext application) {
		super(application);
	}
	
	//  검색 조건에 맞는 게시물 갯수 반환 
	public int selectCount(Map<String, Object> map) {
		int totalCount = 0;			// 게시물 수를 담을 변수
		
		// 게시물 수를 얻어오는 쿼리문
		String query = "SELECT COUNT(*) FROM BOARD";
		if (map.get("searchWord") != null) {
			query += " WHERE " + map.get("searchField") + " " 
					+ " LIKE '%" + map.get("searchWord") + "%'";
		}
		
		try {
			stmt = con.createStatement();		//쿼리문 생성
			rs = stmt.executeQuery(query);		//쿼리문 실행
			
			rs.next();					//커서를 첫 번째 행으로 이동
			totalCount = rs.getInt(1);	//첫 번째 컬럼 값 가져옴
			
		} catch (SQLException e) {
			System.out.println("게시물 수를 구하는 중 예외 발생");
			e.printStackTrace();
		}
		
		return totalCount;
	}
	
	// 검색 조건에 맞는 게시물 목록 반환
	public List<BoardDTO> selectList(Map<String, Object> map) {
		List<BoardDTO> bbs = new ArrayList<>();		//게시물 목록을 담을 변수
		
		String query = "SELECT * FROM BOARD";
		if (map.get("searchWord") != null) {
			query += " WHERE " + map.get("searchField") + " " 
					+ " LIKE '%" + map.get("searchWord") + "%'";
		}
		query += " ORDER BY num desc";
		
		try {
			stmt = con.createStatement();			// 쿼리문 생성
			rs = stmt.executeQuery(query);			// 쿼리문 실행
			
			while(rs.next()) {						// 결과물을 반복하며
				// 게시물 하나(한행)의 내용을 DTO에 저장
				BoardDTO dto = new BoardDTO();
				
				dto.setNum(rs.getString("num"));				// 일련번호
				dto.setTitle(rs.getString("title")); 			// 제목
				dto.setContent(rs.getString("content"));		// 내용
				dto.setPostdate(rs.getDate("postdate"));		// 작성일
				dto.setId(rs.getString("id"));	 				// 작성자 아이디
				dto.setVisitCount(rs.getString("visitCount"));	// 조회수 
				
				bbs.add(dto);									// 결과목록에 저장
			}
			
		} catch (SQLException e) {
			System.out.println("게시물 조회 중 예외 발생");
			e.printStackTrace();
		}
		
		
		return bbs;
	}
	
}



























