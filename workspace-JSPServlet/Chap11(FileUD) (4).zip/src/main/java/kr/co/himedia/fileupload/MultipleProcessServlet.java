package kr.co.himedia.fileupload;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/fileupload/multipleProcess.do")
@MultipartConfig(									
		maxFileSize = 1024 * 1024 * 1,
		maxRequestSize = 1024 * 1024 * 10
)
public class MultipleProcessServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Uploads 디렉토리의 물리적 경로 가져오기
		String saveDirectory = getServletContext().getRealPath("/Uploads");
		
		//다중 파일 업로드 하기
		FileUtility.multipleFile(request, saveDirectory);
		

		
	}
}





























