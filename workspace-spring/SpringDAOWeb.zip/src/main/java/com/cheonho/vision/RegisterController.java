package com.cheonho.vision;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/register")
public class RegisterController {
	@Autowired
	UserDao userDao;
	
	public final int FAIL = 0;
	
	@GetMapping(value = "/add")
	public String register() {
		return "registerForm";
	}
	
	@PostMapping("/save")			// 신규 회원 등록
	public String save(User user, Model m) throws UnsupportedEncodingException {
		//1. 유효성 검사
		int rowCnt = userDao.insertUser(user);
		
		if (rowCnt != FAIL) return "registerinfo";

		return "";
	}

	private boolean isValid(User user) {
		// TODO Auto-generated method stub
		return false;
	}
}











