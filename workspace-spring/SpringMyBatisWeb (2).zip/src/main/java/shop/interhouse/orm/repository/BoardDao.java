package shop.interhouse.orm.repository;

import shop.interhouse.orm.domain.BoardDto;

public interface BoardDao {

	public BoardDto select(Integer bno) throws Exception;
}
