package shop.interhouse.orm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import shop.interhouse.orm.domain.CommentDto;
import shop.interhouse.orm.service.CommentService;

@Controller
public class CommentController {

	@Autowired
	CommentService service;
	
	//지정된 게시물의 모든 댓글을 읽어오는 메서드
	@GetMapping("/comments")			// /comments?bno=296 	GET 
	@ResponseBody
	public ResponseEntity<List<CommentDto>>  list(Integer bno) {
		List<CommentDto> list = null;
		
		try {
			list = service.getList(bno);
			//System.out.println("list = " + list);
			return new ResponseEntity<List<CommentDto>>(list, HttpStatus.OK);		// 200
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<List<CommentDto>>(HttpStatus.BAD_REQUEST);	// 400
		}
		
		//return list;
	}
}
