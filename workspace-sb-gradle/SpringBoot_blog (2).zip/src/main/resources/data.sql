insert into article (title, content) values ('ML P2', 'Hyunjin prepares for presentation')
insert into article (title, content) values ('ML P1', 'Hyojin preparing for presentation')
insert into article (title, content) values ('2 weeks left', 'Lets do our best. go for it!')
