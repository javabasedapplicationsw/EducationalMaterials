package com.seoul.service;

public class BlogService {
}
