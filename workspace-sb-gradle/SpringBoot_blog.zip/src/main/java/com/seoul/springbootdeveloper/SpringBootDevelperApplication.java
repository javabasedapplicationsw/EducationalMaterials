package com.seoul.springbootdeveloper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDevelperApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringBootDevelperApplication.class, args);
    }
}
