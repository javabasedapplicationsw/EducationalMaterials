package com.hillstate.penthouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PenthouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PenthouseApplication.class, args);
	}

}
