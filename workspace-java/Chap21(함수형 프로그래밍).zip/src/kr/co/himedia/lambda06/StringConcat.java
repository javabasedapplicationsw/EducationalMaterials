package kr.co.himedia.lambda06;

public interface StringConcat {
	public void makeString(String s1, String s2);
}
