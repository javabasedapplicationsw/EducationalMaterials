package kr.co.himedia.lambda03;

@FunctionalInterface
public interface MyNumber {
	int getMax(int num1, int num2);
}
