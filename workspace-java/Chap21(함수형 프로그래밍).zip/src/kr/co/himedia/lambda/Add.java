package kr.co.himedia.lambda;

@FunctionalInterface
public interface Add {

	public int add(int x, int y);
	
}
