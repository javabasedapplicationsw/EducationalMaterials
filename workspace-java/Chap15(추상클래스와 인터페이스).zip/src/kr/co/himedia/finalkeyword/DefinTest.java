package kr.co.himedia.finalkeyword;

public class DefinTest {

	public static void main(String[] args) {
		System.out.println(Define.GEETING);
		System.out.println(Define.MIN);
		System.out.println(Define.MAX);
		System.out.println(Define.MATH_CODE);
		System.out.println(Define.KOREAN_CODE);
		System.out.println("원주율은 " +Define.PI+ "입니다.");
	}
}
