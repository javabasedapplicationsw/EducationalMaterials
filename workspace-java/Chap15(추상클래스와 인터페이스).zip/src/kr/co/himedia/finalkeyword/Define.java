package kr.co.himedia.finalkeyword;

public class Define {

	public static final int MIN = 1;
	public static final int MAX = 999999;
	public static final double PI = 3.14;
	public static final String GEETING = "Good Afternoon!";
	public static final int MATH_CODE = 1001;
	public static final int KOREAN_CODE = 1002;
	
}
