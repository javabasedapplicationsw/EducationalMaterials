package kr.co.himedia.abstractclass;

public class MyNoteBook extends NoteBook {

	@Override
	void display() {
		System.out.println("MyNoteBook display()");
	}

}
