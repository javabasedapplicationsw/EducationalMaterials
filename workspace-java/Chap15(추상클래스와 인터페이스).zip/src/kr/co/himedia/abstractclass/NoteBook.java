package kr.co.himedia.abstractclass;

public abstract class NoteBook extends Computer {

	@Override
	void typing() {
		System.out.println("NoteBook typing()");	
	}

}
