package kr.co.himedia.interface06;

public interface X {

	void x();
}
