package kr.co.himedia.interface06;

public interface MyInterface extends X, Y {

	void myMethod();
}
