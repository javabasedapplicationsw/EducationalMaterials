package kr.co.himedia.interface06;

public interface Y {

	void y();
}
